import React, { Component } from 'react';
import './App.css';
import {
  Link,
  withRouter
} from 'react-router-dom'
import { createBrowserHistory } from 'history';
import { browserHistory } from 'react-router';
const history = createBrowserHistory();
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      person: [],
      pagename: '',
      user: {}
    }
  }
  componentWillMount() {
    var that = this;
    var url = 'https://api.github.com/users'

    fetch(url)
      .then(function (response) {
        if (response.status >= 400) {
          throw new Error("Bad response from server");
        }
        return response.json();
      })
      .then(function (data) {
        that.setState({ person: data });
      });
  }

  componentDidMount() {
    this.setState({ pagename: this.props.history.location.pathname })
  }
  componentDidUpdate() {
    if (this.state.pagename != "/") {
      var that = this;
      var url = 'https://api.github.com' + this.state.pagename

      fetch(url)
        .then(function (response) {
          if (response.status >= 400) {
            throw new Error("Bad response from server");
          }
          return response.json();
        })
        .then(function (data) {
          that.setState({ user: data });
        });
    }
  }

  render() {
    const { person } = this.state;
    const { user } = this.state
    if (this.state.pagename == "/") {
      return (
        <div>
          {person.map((user) => {
            return (<ul key={user.id}><li key={user.id} > <Link to={`/users/${user.login}`}>{user.login}</Link></li></ul>)
          })}
        </div>
      )
    } else {
      return (
        <div>
          <img src={user.avatar_url} />
          <label>{user.name}</label>
          <label>{user.location}</label>
        </div>
      )
    }
  }
}

export default App;
