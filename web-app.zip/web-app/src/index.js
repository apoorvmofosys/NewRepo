
import ReactDOM from 'react-dom';
import './index.css';
import registerServiceWorker from './registerServiceWorker';
import {renderRoutes} from '../src/Router/Routes'
ReactDOM.render(renderRoutes(), document.getElementById('root'));
registerServiceWorker();
