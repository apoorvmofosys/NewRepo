import React from 'react';
import { Router, Route, IndexRoute, Switch } from 'react-router';
import { createBrowserHistory } from 'history';

import App from '../App'
import {
    Link,
    Redirect,
    withRouter
} from 'react-router-dom'


const history = createBrowserHistory();

export const renderRoutes = () => (
    <Router history={history}>
        <div>
        <Switch>
            <Route path="/" component={App} />
            </Switch>
        </div>
    </Router>
);
